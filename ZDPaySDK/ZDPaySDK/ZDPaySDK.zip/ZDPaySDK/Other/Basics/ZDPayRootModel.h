//
//  ZDPayRootModel.h
//  ReadingEarn
//
//  Created by FANS on 2020/4/13.
//  Copyright © 2020 FANS. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface ZDPayRootModel : NSObject

@end

NS_ASSUME_NONNULL_END
