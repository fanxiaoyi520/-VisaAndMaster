//
//  ZDPay_AddBankCardReqModel.m
//  ZDPaySDK
//
//  Created by FANS on 2020/4/20.
//  Copyright © 2020 ZhongDaoGroup. All rights reserved.
//

#import "ZDPay_AddBankCardReqModel.h"

@implementation ZDPay_AddBankCardReqModel

@end
