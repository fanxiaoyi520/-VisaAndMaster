//
//  ZDPay_SafetyCertificationViewController.h
//  ReadingEarn
//
//  Created by FANS on 2020/4/15.
//  Copyright © 2020 FANS. All rights reserved.
//

#import "ZDPayRootViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface ZDPay_SafetyCertificationViewController : ZDPayRootViewController

@end

NS_ASSUME_NONNULL_END
