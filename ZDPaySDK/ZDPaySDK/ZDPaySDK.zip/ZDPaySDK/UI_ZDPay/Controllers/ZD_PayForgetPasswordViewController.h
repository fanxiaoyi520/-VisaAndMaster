//
//  ZD_PayForgetPasswordViewController.h
//  ZDPaySDK
//
//  Created by FANS on 2020/4/22.
//  Copyright © 2020 ZhongDaoGroup. All rights reserved.
//

#import "ZDPayRootViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface ZD_PayForgetPasswordViewController : ZDPayRootViewController

@end

NS_ASSUME_NONNULL_END
