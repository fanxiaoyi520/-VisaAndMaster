

#import <Foundation/Foundation.h>
#import "WXUtil.h"
#import "ApiXml.h"
#import "WeiXinPayTool.h"



@interface payRequsestHandler : NSObject{
	//预支付网关url地址
    NSString *payUrl;

    //lash_errcode;
    long     last_errcode;
	//debug信息
    NSMutableString *debugInfo;
    NSString *appid,*mchid,*spkey;
}
//初始化函数
-(BOOL) init:(NSString *)app_id mch_id:(NSString *)mch_id;
-(NSString *) getDebugifo;
-(long) getLasterrCode;
//设置商户密钥
-(void) setKey:(NSString *)key;
//创建package签名
-(NSString*) createMd5Sign:(NSMutableDictionary*)dict;
//获取package带参数的签名包
-(NSString *)genPackage:(NSMutableDictionary*)packageParams;
//提交预支付
-(NSString *)sendPrepay:(NSMutableDictionary *)prePayParams;
//签名实例测试
- ( NSMutableDictionary *)sendPay_demoWithopenID:(NSString *)openID
                                       partnerId:(NSString *)partnerId
                                        prepayId:(NSString *)prepayId
                                        nonceStr:(NSString *)nonceStr
                                       timeStamp:(NSString *)timeStamp
                                         package:(NSString *)package;
- (NSMutableDictionary *)sendPay_demoWith:(NSString *)orderName withOrderId:(NSString *)orderId withPrise:(NSString *)prise;

@end