//
//  PayModel.m
//  AllPayDemo
//
//  Created by FANS on 2020/4/2.
//  Copyright © 2020 彭金光. All rights reserved.
//

#import "PayModel.h"

@implementation PayModel

@end
